GAN
 Data set download link 
 https://drive.google.com/file/d/0B7EVK8r0v71pZjFTYXZWM3FlRnM/view?usp=drive_link&resourcekey=0-dYn9z10tMJOBAkviAcfdyQ

 For more detailes visit this link :
https://trello.com/c/9nE53HeA/1-downloads-requirements